﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiTouchEmit : MonoBehaviour {

	private ParticleSystem System;
	private Camera Cam;

	// Use this for initialization
	void Start () {
		Cam = Camera.main;
		System = GetComponent<ParticleSystem>();
		System.Stop();
	}
	
	// Update is called once per frame
	void Update () {

		// Print out the number of currently detected touches. Different devices
		// have different numbers of touches that can be tracked. E.g. the fire
		// tablets can track up to 2 fingers, while my S6 can track at least 5
		// fingers.
		Debug.Log("Fingers on the screen: " + Input.touchCount);

		// Since there are (potentially) multiple fingers on the screen, the 
		// touch information is stored in an array (Input.touches). Each Touch
		// instance in the array has information like position, fingerId, phase,
		// etc.
		foreach (Touch touch in Input.touches) {

			// Touch.phase gives us the state of the touch. TouchPhase.Began
			// means that a touch has just started.
			if (touch.phase == TouchPhase.Began) {
				Ray ray = Cam.ScreenPointToRay(touch.position);
				Vector3 targetPoint = ray.GetPoint(10f);
				transform.position = targetPoint;
				System.Emit(20);
			}

		}
	}
}
