﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveToMouse : MonoBehaviour {
	
	private Camera Cam;

	// Use this for initialization
	void Start () {
		Cam = Camera.main;		
	}
	
	// Update is called once per frame
	void Update () {
		Ray ray = Cam.ScreenPointToRay(Input.mousePosition);
		Vector3 targetPoint = ray.GetPoint(10f);
		transform.position = targetPoint;		
	}
}
