﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttractToTarget : MonoBehaviour {

	public Transform Target;
	public float MaxTurnSpeed = 3f;
	public float MaxSpeedChange = 3f;

	private ParticleSystem System;
	private ParticleSystem.Particle[] Particles;

	void Start() {
		System = GetComponent<ParticleSystem>();

		// Create an array that is large enough to accomodate the maximum number
		// of particles the particle system can have. This maximum number is
		// set in the inspector on the particle system component.
		Particles = new ParticleSystem.Particle[System.maxParticles];
	}

	void LateUpdate() {

		// Run this while the left mouse button is *held down*
		if (Input.GetMouseButton(0)) {

			// Get the particles that are alive and store them into our 
			// Particles array
			int numParticlesAlive = System.GetParticles(Particles);

			float dt = Time.deltaTime;

			// Loop over the alive particles in the array
			for (int i = 0; i < numParticlesAlive; i++) {
				// Figure out how to get from the particle's current position
				// to the target's position
				Vector3 targetHeading = Target.transform.position - Particles[i].position;

				// Teleport the particle to the target (not exactly what we 
				// wanted...)
//				Particles[i].position += targetHeading;

				// Instead of teleporting, we can make a small change to the
				// particle's current velocity. We will take the current 
				// velocity (a vector3) and rotate it towards the targetHeader
				// (another vector3).
				Vector3 vel = Vector3.RotateTowards(Particles[i].velocity, 
					targetHeading, MaxTurnSpeed * dt, MaxSpeedChange * dt);
				Particles[i].velocity = vel;
			}

			// Put the updated particles back into the system
			System.SetParticles(Particles, numParticlesAlive);
		}

	}
}

