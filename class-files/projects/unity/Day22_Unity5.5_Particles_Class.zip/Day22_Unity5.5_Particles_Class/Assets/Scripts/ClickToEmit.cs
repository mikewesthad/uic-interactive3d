﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickToEmit : MonoBehaviour {

	private ParticleSystem System;
	private Camera Cam;

	// Use this for initialization
	void Start () {
		Cam = Camera.main;
		System = GetComponent<ParticleSystem>();
		System.Stop();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown(0)) {
			Ray ray = Cam.ScreenPointToRay(Input.mousePosition);
			Vector3 targetPoint = ray.GetPoint(10f);
			transform.position = targetPoint;
			System.Emit(20);
		}
	}
}
