﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttractToTarget : MonoBehaviour {

	void Start() {
		
	}

	void LateUpdate() {

	}
}

