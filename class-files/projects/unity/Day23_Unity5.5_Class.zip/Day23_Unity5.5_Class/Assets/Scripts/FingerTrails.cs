﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FingerTrails : MonoBehaviour {

	public GameObject TrailPrefab;

	private Dictionary<int, GameObject> FingerObjects = new Dictionary<int, GameObject>();

	void Update () {
		foreach (Touch touch in Input.touches) {

			int id = touch.fingerId;

			if (touch.phase == TouchPhase.Began) {
				GameObject trail = CreateNewTrail();
				trail.transform.position = CamToWorldPoint(touch.position);
				trail.name = "Finger " + id;
				FingerObjects.Add(id, trail);
			} else if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled) {
				GameObject trail = FingerObjects[id];
				Destroy(trail);
				FingerObjects.Remove(id);
			} else {
				GameObject trail = FingerObjects[id];
				trail.transform.position = CamToWorldPoint(touch.position);
			}
		}
	}

	GameObject CreateNewTrail() {
		GameObject trail = (GameObject) Instantiate(TrailPrefab, transform);
		Color color = Random.ColorHSV(0.2f, 1f, 0.2f, 0.7f, 1, 1);
		trail.GetComponent<MeshRenderer>().material.SetColor("_EmissionColor", color);
		trail.GetComponent<TrailRenderer>().material.SetColor("_EmissionColor", color);
		return trail;
	}

	Vector3 CamToWorldPoint(Vector3 screenPosition) {
		Ray ray = Camera.main.ScreenPointToRay(screenPosition);
		Vector3 worldPoint = ray.GetPoint(20f);
		return worldPoint;
	}
}