﻿using UnityEngine;
using System.Collections;

public class LogicalOperators : MonoBehaviour {

	private Camera Cam;

	// Use this for initialization
	void Start () {
		Cam = GetComponent<Camera>();	
	}
	
	// Update is called once per frame
	void Update () {

		// "And" Operator

		// "Or" Operator

		// "Not" operator

		// Combining

	}
}
