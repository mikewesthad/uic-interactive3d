﻿using UnityEngine;
using System.Collections;

public class MicController : MonoBehaviour {

	private AudioSource Audio;
	private Rigidbody RigidbodyComponent;
	private bool HasJustFlapped = false;

	void Start () {
		Audio = GetComponent<AudioSource>();
		Audio.clip = Microphone.Start(null, true, 3, 44100);

		RigidbodyComponent = GetComponent<Rigidbody>();
	}
		
	// Update is called once per frame
	void Update () {
		if (!Audio.isPlaying && Microphone.GetPosition(null) > 0) {
			Audio.Play();
		}

		float volume = GetVolume(256, Audio);

		// Alternate: mouse controls
		if (Input.GetMouseButtonDown(0)) {
			RigidbodyComponent.AddForce(Vector3.up * 3f, ForceMode.Impulse);
			HasJustFlapped = true;
			Invoke("ResetFlapping", 0.1f);
		}

		// Mic controls
		if (!HasJustFlapped && (volume > 0.02)) {
			RigidbodyComponent.AddForce(Vector3.up * 3f, ForceMode.Impulse);
			HasJustFlapped = true;
			Invoke("ResetFlapping", 0.1f);
		}

		// Constant horizontal motion
		Vector3 vel = RigidbodyComponent.velocity;
		vel.x = 10f;
		RigidbodyComponent.velocity = vel;
	}

	void ResetFlapping() {
		HasJustFlapped = false;
	}

	float GetVolume(int numSamples, AudioSource audio) {
		// numSamples must be a power of 2
		float[] samples = new float[numSamples];
		// Get a sampling of audio signals from the AudioSource
		audio.GetOutputData(samples, 0);
		float sum = 0f;
		// Sum the square of the samples
		for (int i = 0; i < numSamples; i++){
			sum += samples[i] * samples[i];
		}
		float squaredAverage = sum / numSamples;
		float rootMeanSquare = Mathf.Sqrt(squaredAverage);
		return rootMeanSquare;
	}

}
