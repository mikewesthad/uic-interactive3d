Hey!

Glad you are using our free low poly models!

These are just a few samples from our huge low poly packs. You can find them here:
https://goo.gl/4e2dbm (Unity Asset Store)

Please leave a review on the Unity Asset Store :)
Also follow us on Twitter: https://twitter.com/Broken_vector