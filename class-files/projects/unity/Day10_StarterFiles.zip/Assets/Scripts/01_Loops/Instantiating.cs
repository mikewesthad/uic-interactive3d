﻿using UnityEngine;
using System.Collections;

public class Instantiating : MonoBehaviour {

	// Use this for initialization
	void Start () {

		// Creating a copy of an object

		// Spawning and casting

		// Looping and spawning a row

		// Mapping 
		// Challenge: create a row that forms a rainbow of colors

		// Grid - 2D loop

		// Challenge: create a grid where hue changes along the x-axis and value
		// changes along the y-axis
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
