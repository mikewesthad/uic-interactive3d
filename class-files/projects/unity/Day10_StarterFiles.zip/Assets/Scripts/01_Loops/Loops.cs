﻿using UnityEngine;
using System.Collections;

public class Loops : MonoBehaviour {

	// Use this for initialization
	void Start () {

		// Summing all the numbers from 1 to 10 together

		// Write a loop that prints the numbers 5 through 15

		// Write a loop that counts from 0 through 100, in increments of 10

		// Write a loop that counts down from 10 to 0
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
