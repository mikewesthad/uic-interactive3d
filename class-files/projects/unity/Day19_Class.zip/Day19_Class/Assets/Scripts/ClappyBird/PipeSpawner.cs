﻿using UnityEngine;
using System.Collections;

public class PipeSpawner : MonoBehaviour {

	public GameObject TopPipe;
	public GameObject BottomPipe;
	public GameObject ScoreTrigger;
	public Transform PlayerTransform;

	// Use this for initialization
	void Start () {
		Invoke("SpawnPipe", 0.5f);
	}

	void SpawnPipe() {
		float x = PlayerTransform.position.x + 15f;
		float openingSize = Random.Range(3.5f, 4.5f);
		float offset = Random.Range(-2.25f, 2.25f);

		float yTop = (openingSize / 2f) + offset;
		GameObject topPipe = (GameObject) Instantiate(TopPipe, transform);
		topPipe.transform.position = new Vector3(x, yTop, 0f);

		float yBottom = -(openingSize / 2f) + offset;
		GameObject bottomPipe = (GameObject) Instantiate(BottomPipe, transform);
		bottomPipe.transform.position = new Vector3(x, yBottom, 0f);

		GameObject trigger = (GameObject) Instantiate(ScoreTrigger, transform);
		trigger.transform.position = new Vector3(x, 0f, 0f);

		Invoke("SpawnPipe", 3f);
	}

	// Update is called once per frame
	void Update () {
	
	}
}
