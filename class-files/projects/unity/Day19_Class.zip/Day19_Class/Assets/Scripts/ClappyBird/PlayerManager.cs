﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour {

	public Text ScoreText;
	private float Score;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision collision) {
		if (collision.gameObject.tag == "Pipe") {
			Scene activeScene = SceneManager.GetActiveScene();
			SceneManager.LoadScene(activeScene.name);
		}
	}

	void OnTriggerEnter(Collider other) {
		if (other.tag == "ScoreTrigger") {
			Score += 1;
			ScoreText.text = "Score: " + Score;
		}
	}

}
