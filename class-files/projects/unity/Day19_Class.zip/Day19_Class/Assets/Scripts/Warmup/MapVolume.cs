﻿using UnityEngine;
using System.Collections;

public class MapVolume : MonoBehaviour {

	private AudioSource Audio;
	private Light LightComponent;

	// Use this for initialization
	void Start () {
		Audio = GetComponent<AudioSource>();
		LightComponent = GetComponent<Light>();
	}
	
	// Update is called once per frame
	void Update () {
		float volume = GetVolume(256, Audio);
		LightComponent.intensity = volume * 16f;

		transform.Rotate(45f * Time.deltaTime, 0, 45f * Time.deltaTime);
	}

	float GetVolume(int numSamples, AudioSource audio) {
		// numSamples must be a power of 2
		float[] samples = new float[numSamples];
		// Get a sampling of audio signals from the AudioSource
		audio.GetOutputData(samples, 0);
		float sum = 0f;
		// Sum the square of the samples
		for (int i = 0; i < numSamples; i++){
			sum += samples[i] * samples[i];
		}
		float squaredAverage = sum / numSamples;
		float rootMeanSquare = Mathf.Sqrt(squaredAverage);
		return rootMeanSquare;
	}
}
