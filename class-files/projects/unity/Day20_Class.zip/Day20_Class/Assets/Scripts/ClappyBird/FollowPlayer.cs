﻿using UnityEngine;
using System.Collections;

public class FollowPlayer : MonoBehaviour {

	public Transform PlayerTransform;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		// Copy the camera's current position
		Vector3 pos = transform.position;
		// Move the x component
		pos.x = PlayerTransform.position.x;
		// Update the camera's position
		transform.position = pos;

	}
}
