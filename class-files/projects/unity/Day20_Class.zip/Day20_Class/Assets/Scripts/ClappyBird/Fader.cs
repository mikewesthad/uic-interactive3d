﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Fader : MonoBehaviour {

	public Image FadeImage;
	public Color FadeColor = Color.black;
	public float FadeDuration = 1.25f;

	private bool IsFadingIn = false;
	private bool IsFadingOut = false;

	// Use this for initialization
	void Start () {
		FadeImage.color = FadeColor;
		StartFadeIn(1f);
	}

	public void StartFadeIn(float duration) {
		IsFadingIn = true;
		FadeColor.a = 1;
		FadeImage.color = FadeColor;
		FadeDuration = duration;
	}

	public void StartFadeOut(float duration) {
		IsFadingOut = true;
		FadeColor.a = 0;
		FadeImage.color = FadeColor;
		FadeDuration = duration;
	}
	
	// Update is called once per frame
	void Update () {
		
		if (IsFadingIn) {			
			FadeColor.a -= (1f / FadeDuration) * Time.deltaTime;
			if (FadeColor.a <= 0) {
				IsFadingIn = false;
			}
			FadeImage.color = FadeColor;
		} else if (IsFadingOut) {			
			FadeColor.a += (1f / FadeDuration) * Time.deltaTime;
			if (FadeColor.a >= 1) {
				IsFadingOut = false;
			}
			FadeImage.color = FadeColor;
		}
	
	}
}
