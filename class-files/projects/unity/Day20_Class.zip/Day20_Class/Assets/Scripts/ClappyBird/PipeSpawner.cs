﻿using UnityEngine;
using System.Collections;

public class PipeSpawner : MonoBehaviour {

	public GameObject TopPipe;
	public GameObject BottomPipe;
	public GameObject ScoreTrigger;
	public Transform PlayerTransform;

	private float SpawnDelay = 3f;
	private float OpeningSize = 6f;

	// Use this for initialization
	void Start () {
		Invoke("SpawnPipe", 0.5f);
	}

	void SpawnPipe() {			
		float x = PlayerTransform.position.x + 15f;
		float offset = Random.Range(-2.25f, 2.25f);

		OpeningSize -= 0.25f;
		if (OpeningSize <= 3f) {
			OpeningSize = 3f;
		}

		float yTop = (OpeningSize / 2f) + offset;
		GameObject topPipe = (GameObject) Instantiate(TopPipe, transform);
		topPipe.transform.position = new Vector3(x, yTop, 0f);

		float yBottom = -(OpeningSize / 2f) + offset;
		GameObject bottomPipe = (GameObject) Instantiate(BottomPipe, transform);
		bottomPipe.transform.position = new Vector3(x, yBottom, 0f);

		GameObject trigger = (GameObject) Instantiate(ScoreTrigger, transform);
		trigger.transform.position = new Vector3(x, 0f, 0f);

		SpawnDelay -= 0.25f;
		if (SpawnDelay <= 0.5f) {
			SpawnDelay = 0.5f;
		}
		Invoke("SpawnPipe", SpawnDelay);
	}

	// Update is called once per frame
	void Update () {
	
	}
}
