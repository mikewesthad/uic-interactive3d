﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour {

	public Fader FaderScript;
	public Text ScoreText;

	private float Score;
	private Rigidbody RigidbodyComponent;

	// Use this for initialization
	void Start () {
		RigidbodyComponent = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision collision) {
		if (collision.gameObject.tag == "Pipe") {
			RigidbodyComponent.constraints = RigidbodyConstraints.FreezeAll;
			FaderScript.StartFadeOut(0.5f);
			Invoke("ResetLevel", 0.75f);
		}
	}

	void ResetLevel() {
		Scene activeScene = SceneManager.GetActiveScene();
		SceneManager.LoadScene(activeScene.name);
	}

	void OnTriggerEnter(Collider other) {
		if (other.tag == "ScoreTrigger") {
			Score += 1;
			ScoreText.text = "Score: " + Score;
		}
	}

}
