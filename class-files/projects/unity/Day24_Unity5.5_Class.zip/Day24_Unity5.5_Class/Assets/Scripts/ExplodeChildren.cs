﻿/*
 * 1. Make the fractured shards explode out (rather than crumple).
 * 
 * 2. Make the explosion happen *ONLY* when the player gets close to
 *    the sculpture. (Hint: think triggers or distance.)
 */

using UnityEngine;
using System.Collections;

public class ExplodeChildren : MonoBehaviour {

	private bool HasExploded = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter(Collider collider) {
		// Only explode when the collider is the RigidbodyFPSController and
		// when HasExploded is not true. This prevents the explosion code from
		// running more than once.
		if (collider.tag == "Player" && !HasExploded) {
			foreach (Transform child in transform) {
				Rigidbody rb = child.GetComponent<Rigidbody>();
				rb.isKinematic = false;
				rb.AddExplosionForce(1000f, transform.position, 50f);
			}
			HasExploded = true;
		}
	}
}
