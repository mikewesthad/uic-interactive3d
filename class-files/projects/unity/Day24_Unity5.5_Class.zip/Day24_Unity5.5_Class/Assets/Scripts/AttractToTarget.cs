﻿/*
 * Extensions:
 * 
 * 1. Make a particle system where particles chase the player ONLY when the 
 * player is within some distance of a particle.
 * 
 * 2. Make a particle system that chases a randomly changing target.
 * 
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttractToTarget : MonoBehaviour {

	public Transform Target;
	public float MaxTurnSpeed = 3f;
	public float MaxSpeedChange = 3f;

	private ParticleSystem System;
	private ParticleSystem.Particle[] Particles;

	void Start() {
		System = GetComponent<ParticleSystem>();
		Particles = new ParticleSystem.Particle[System.maxParticles];
	}

	void LateUpdate() {
		// Get particles
		int numParticlesAlive = System.GetParticles(Particles);
		float dt = Time.deltaTime;

		// Change only the particles that are alive
		for (int i = 0; i < numParticlesAlive; i++) {

			float dist = Vector3.Distance(Target.transform.position, 
				Particles[i].position);

			Vector3 targetHeading = Target.transform.position - Particles[i].position;
			Vector3 newVel = Vector3.RotateTowards(Particles[i].velocity, 
				targetHeading, MaxTurnSpeed * dt, MaxSpeedChange * dt);
			Particles[i].velocity = newVel;

		}

		// Apply the particle changes to the particle system
		System.SetParticles(Particles, numParticlesAlive);
	}
}

