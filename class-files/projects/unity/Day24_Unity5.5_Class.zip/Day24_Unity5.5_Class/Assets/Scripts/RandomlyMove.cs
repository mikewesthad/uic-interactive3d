﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomlyMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Invoke("Teleport", 1f);
	}

	void Teleport() {
		transform.position = new Vector3(
			Random.Range(-10f, 10f),
			Random.Range(1f, 5f),
			Random.Range(-10f, 10f)
		);
		Invoke("Teleport", 3f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
