﻿using UnityEngine;
using System.Collections;

public class Script07_Instantiating : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
